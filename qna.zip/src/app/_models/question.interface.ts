export interface IQuestion {
  id: string;
  title: string;
  inputType: string;
  options?: any;
}
